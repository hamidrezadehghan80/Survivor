package se.survivor.net.exceptions;

public class InvalidValueException extends Exception {
    public InvalidValueException(String message) {
        super(message);
    }
}
