package se.survivor.net.DTO;

import se.survivor.net.models.Post;

import java.util.List;

public class PostDTO {
    public PostDTO(Post post, long commentCount, long reactionCount, Post parent) {
    }
}
