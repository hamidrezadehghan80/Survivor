package se.survivor.net.exceptions;

public class InvalidRequestParamsException extends Throwable {
    public InvalidRequestParamsException(String message) {
        super(message);
    }
}
